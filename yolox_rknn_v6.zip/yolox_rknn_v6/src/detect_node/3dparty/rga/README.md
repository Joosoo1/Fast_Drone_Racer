# RGA
The RGA libraries and docs are obtained from https://github.com/airockchip/librga